<?php
include("../include/dbcommon.php");
header('Content-Type: application/json');

// Step 1: Authenticate using API key
$headers = getallheaders();

// Step 2: Read and validate input JSON
$body = json_decode(file_get_contents("php://input"), true);

$api_key = $body['api_key'] ?? $body['Api_Key'] ?? null;

if (!$api_key) {
    http_response_code(401);
    echo json_encode(['error' => 'Missing API key']);
    exit;
}

try {
    $sql = "SELECT * FROM umUserInfo WHERE api_key = '" . db_addslashes($api_key) . "'";
    $rs = DB::Query($sql);
    $user = $rs->fetchAssoc();

    if (!$user) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid API key']);
        exit;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'API key check failed: ' . $e->getMessage()]);
    exit;
}


if (!$body || !isset($body['id']) || !isset($body['master'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid master data']);
    exit;
}

$master_id = (int)$body['id'];
$master = $body['master'] ?? [];
$details = $body['details'] ?? [];

try {
    // Step 3: Fetch existing master record
    $existing_master = DB::Query("SELECT * FROM tSaleH WHERE ID = " . $master_id)->fetchAssoc();

    if (!$existing_master) {
        http_response_code(404);
        echo json_encode(['error' => 'Master record not found']);
        exit;
    }

    // Step 4: Update tSaleH (master record)
    $currentMonthNumber = date('m');
    $currentYear = date('y');
    $currentdatetime = now();

    $masterData = array();
    $masterData["TMonth"] = $currentMonthNumber;
    $masterData["TYear"] = $currentYear;
    $masterData["BookCode"] = 3;
    $masterData["BookID"] = 3;
    $masterData["TBook"] = "POS";
    $masterData["TType"] = "Point OF Sale";
    $masterData["TDate"] = $currentdatetime;
    $masterData["BUnit"] = 1;
    $masterData["Status"] = "OPEN";
    $masterData["PartyCode"] = $master["PartyCode"];
    $masterData["TotalAmount"] = $master["TotalAmount"];
    $masterData["FreightAccountCode"] = $master["FreightAccountCode"] ?? null;
    $masterData["FreightCharges"] = $master["FreightCharges"] ?? 0;
    $masterData["LaborAccountCode"] = $master["LaborAccountCode"];
    $masterData["LaborCharges"] = $master["LaborCharges"];
    $masterData["SaleTaxAccCode"] = $master["SaleTaxAccCode"];
    $masterData["SaleTaxRate"] = $master["SaleTaxRate"];
    $masterData["SaleTaxAmount"] = $master["SaleTaxAmount"];
    $masterData["DiscountAccCode"] = $master["DiscountAccCode"];
    $masterData["DiscountRemarks"] = $master["DiscountRemarks"];
    $masterData["DiscountRate"] = $master["DiscountRate"];
    $masterData["DiscountAmount"] = $master["DiscountAmount"];
    $masterData["GrandTotal"] = $master["GrandTotal"];
    $masterData["SaleMenCode"] = $master["SaleMenCode"];
    $masterData["Commission"] = $master["Commission"];
    $masterData["Remarks"] = $master["Remarks"];
    $masterData["UpdateUser"] = $user["Code"];
    $masterData["UpdateDate"] = $currentdatetime;
    $masterData["UpdateTime"] = $currentdatetime;
		$masterData["SaleType"] = $master["SaleType"];
    $masterData["Block"] = $master["Block"];

    DB::Update("tSaleH", $masterData, "ID = " . $master_id);

    // Step 5: Loop through detail items
    $incomingDetailIds = [];

    foreach ($details as $entry) {
        $detailData = array();
        $detailData["Code"] = $master_id;
        $detailData["VirtualCode"] = $existing_master["VirtualCode"];
        $detailData["Tdate"] = $currentdatetime;
        $detailData["PartyCode"] = $master["PartyCode"];
        $detailData["StoreCode"] = 1;
        $detailData["ProductCode"] = $entry["ProductCode"];
        $detailData["ProductGroupCode"] = $entry["ProductGroupCode"];
        $detailData["UnitCode"] = $entry["UnitCode"];
        $detailData["Qty"] = $entry["Qty"];
        $detailData["Rate"] = $entry["Rate"];
        $detailData["Amount"] = $entry["Amount"];
        $detailData["Remarks"] = $entry["Remarks"];

        $detailData["Block"] = $entry["Block"];
        $detailData["BuCode"] = 1;

        if (!empty($entry["id"]) && (int)$entry["id"] > 0) {
            // Update existing detail record
					  $detailData["UpdateUser"] = $user["Code"];
					  $detailData["UpdateDate"] = $currentdatetime;
					  $detailData["UpdateTime"] = $currentdatetime;
            DB::Update("tSaleD", $detailData, "CodeD = " . (int)$entry["id"]);
            $incomingDetailIds[] = (int)$entry["id"];
        } else {
            // Insert new detail record
					  $detailData["UserName"] = $user["Code"];
					  $detailData["CreateDate"] = $currentdatetime;
					  $detailData["UpdateTime"] = $currentdatetime;
            DB::Insert("tSaleD", $detailData);
            $incomingDetailIds[] = DB::LastId();
        }
    }

    // Step 6: Remove any detail records not in incoming list
    if (!empty($incomingDetailIds)) {
        $idList = implode(",", $incomingDetailIds);
        DB::Exec("DELETE FROM tSaleD WHERE Code = $master_id AND CodeD NOT IN ($idList)");
    } else {
        DB::Exec("DELETE FROM tSaleD WHERE Code = $master_id");
    }

		DB::Exec("DELETE FROM GLTD WHERE VirtualCode = '" . $existing_master["VirtualCode"]."'");
	  DB::Exec("DELETE FROM GltH WHERE VirtualCode = '" . $existing_master["VirtualCode"]."'");

		$accountCode = ($master["SaleType"] == "Cash") ? 11 : $master["PartyCode"];
		$pAccounts = DB::Query("SELECT * FROM pAccounts WHERE Code = " . $accountCode);
		$row = $pAccounts->fetchAssoc();
		$paccount_code = $row["ID"];
		$paccount_name = $row["Name"];
        $sale_narration = "Sales id ".$master_id." of Amount ".$master["GrandTotal"]." on Account ".$row["Name"];

    $gltHData = array();
    $gltHData["BookCode"] = $existing_master["Code"];
    $gltHData["VirtualCode"] = $existing_master["VirtualCode"];
    $gltHData["TBook"] = "POS";
    $gltHData["TType"] = "Point OF Sale";
    $gltHData["TDate"] = $currentdatetime;
    $gltHData["BUnit"] = 1;
    $gltHData["Status"] = "OPEN";
    $gltHData["Remarks"] = $master["Remarks"];
    $gltHData["UserName"] = $user["Code"];
    $gltHData["CreateDate"] = $currentdatetime;
    $gltHData["CreateTime"] = $currentdatetime;
    $gltHData["Block"] = 0;
    $gltHData["Lock"] = 0;
    $gltHData["TotalAmount"] = $master["GrandTotal"];
    DB::Insert("GltH", $gltHData);


    $glth_id = DB::LastId();


    $gltdparty = array();
    $gltdparty["Code"] = $glth_id;
    $gltdparty["BookCode"] = $existing_master["Code"];
    $gltdparty["BookID"] = 3;
    $gltdparty["VirtualCode"] = $existing_master["VirtualCode"];
    $gltdparty["Status"] = "OPEN";
    $gltdparty["TDate"] = $currentdatetime;
    $gltdparty["BUnit"] = 1;
    $gltdparty["TBook"] = "POS";
    $gltdparty["TType"] = "Point OF Sale";
    $gltdparty["Narration"] = $sale_narration;
    $gltdparty["ParentAccountCode"] = $paccount_code;
    $gltdparty["AccountCode"] = $accountCode;
    $gltdparty["Remarks"] = $row["Remarks"];
    $gltdparty["Amount"] = $master["TotalAmount"];
    $gltdparty["StoreCode"] = 1;
    $gltdparty["UserName"] = $user["Code"];
    $gltdparty["CreateDate"] = $currentdatetime;
    $gltdparty["CreateTime"] = $currentdatetime;
    $gltdparty["Block"] = $row["Block"];
    $gltdparty["ProductCode"] = $row["ProductCode"];
    $gltdparty["ProductGroupCode"] = $row["ProductGroupCode"];
    $gltdparty["UnitCode"] = $row["UnitCode"];
    $gltdparty["TStatus"] = "Dr";
    DB::Insert("GLTD", $gltdparty);

    // ✅ Insert into GLTD (loop through tSaleD)
    $saleD = DB::Query("SELECT * FROM tSaleD WHERE Code = " . $master_id);
    while ($row = $saleD->fetchAssoc()) {
        $pAccountsSale = DB::Query("SELECT * FROM pAccounts WHERE Code = ". 22);
		$rowSale = $pAccountsSale->fetchAssoc();
		$paccount_code = $rowSale["ID"];
    
        $productAccountsSale = DB::Query("SELECT * FROM pproductitems WHERE ID = ". $row["ProductCode"]);
		$rowProductSale = $productAccountsSale->fetchAssoc();
		$product_account_code = $rowProductSale["Code"];

        $proAccountsSale = DB::Query("SELECT * FROM pAccounts WHERE Code = ". $product_account_code);
		$rowProSale = $proAccountsSale->fetchAssoc();
		$pro_account_code = $rowProSale["ID"];
		$pro_name = $rowProSale["Name"];
        
        $product_sale_narration = $pro_name." @ ".$row["Rate"]."x".$row["Qty"]." Total Amount ".$row["Amount"]." Account ".$paccount_name;

        $gltd = array();
        $gltd["Code"] = $glth_id;
        $gltd["BookCode"] = $existing_master["Code"];
        $gltd["BookID"] = 3;
        $gltd["VirtualCode"] = $existing_master["VirtualCode"];
        $gltd["Status"] = "OPEN";
        $gltd["TDate"] = $currentdatetime;
        $gltd["BUnit"] = 1;
        $gltd["TBook"] = "POS";
        $gltd["TType"] = "Point OF Sale";
        $gltd["Narration"] = $product_sale_narration;
        $gltd["ParentAccountCode"] = $paccount_code;
        $gltd["AccountCode"] = 22;
        $gltd["Remarks"] = $row["Remarks"];
        $gltd["Amount"] = $row["Amount"];
        $gltd["StoreCode"] = 1;
        $gltd["Qty"] = $row["Qty"];
        $gltd["Rate"] = $row["Rate"];
        $gltd["UserName"] = $user["Code"];
        $gltd["CreateDate"] = $currentdatetime;
        $gltd["CreateTime"] = $currentdatetime;
        $gltd["Block"] = $row["Block"];
        $gltd["ProductCode"] = $row["ProductCode"];
        $gltd["ProductGroupCode"] = $row["ProductGroupCode"];
        $gltd["UnitCode"] = $row["UnitCode"];
        $gltd["TStatus"] = "Cr";
        DB::Insert("GLTD", $gltd);
    }
    if ($master["SaleMenCode"]) {
        $pAccountsSaleMan = DB::Query("SELECT * FROM pAccounts WHERE Code = ". $master["SaleMenCode"]);
		$rowSaleMan = $pAccountsSaleMan->fetchAssoc();
		$paccount_codesaleman = $rowSaleMan["ID"];
        $commission_account_narration = "Get Comissionn ".$master["Commission"]." from sale ".$master_id;
        $gltdsalemenDr = array();
        $gltdsalemenDr["Code"] = $glth_id;
        $gltdsalemenDr["BookCode"] = $existing_master["Code"];
        $gltdsalemenDr["BookID"] = 3;
        $gltdsalemenDr["VirtualCode"] = $existing_master["VirtualCode"];
        $gltdsalemenDr["Status"] = "OPEN";
        $gltdsalemenDr["TDate"] = $currentdatetime;
        $gltdsalemenDr["BUnit"] = 1;
        $gltdsalemenDr["TBook"] = "POS";
        $gltdsalemenDr["TType"] = "Point OF Sale";
        $gltdsalemenDr["Narration"] = $commission_account_narration;
        $gltdsalemenDr["ParentAccountCode"] = $paccount_codesaleman;
        $gltdsalemenDr["AccountCode"] = $master["SaleMenCode"];
        $gltdsalemenDr["Remarks"] = $row["Remarks"];
        $gltdsalemenDr["Amount"] = $master["Commission"];
        $gltdsalemenDr["StoreCode"] = 1;
        $gltdsalemenDr["UserName"] = $user["Code"];
        $gltdsalemenDr["CreateDate"] = $currentdatetime;
        $gltdsalemenDr["CreateTime"] = $currentdatetime;
        $gltdsalemenDr["Block"] = $row["Block"];
        $gltdsalemenDr["ProductCode"] = $row["ProductCode"];
        $gltdsalemenDr["ProductGroupCode"] = $row["ProductGroupCode"];
        $gltdsalemenDr["UnitCode"] = $row["UnitCode"];
        $gltdsalemenDr["TStatus"] = "Dr";
        DB::Insert("GLTD", $gltdsalemenDr);

        $pAccountsSaleManCr = DB::Query("SELECT * FROM pAccounts WHERE Code = 29");
		$rowSaleManCr = $pAccountsSaleManCr->fetchAssoc();
		$paccount_codesalemanCr = $rowSaleManCr["ID"];
        $commission_saleman_account_narration = "Get Comissionn ".$master["Commission"]." from sale id ".$master_id." Salesman ".$rowSaleMan["Name"];
        $gltdsalemenCr = array();
        $gltdsalemenCr["Code"] = $glth_id;
        $gltdsalemenCr["BookCode"] = $existing_master["Code"];
        $gltdsalemenCr["BookID"] = 3;
        $gltdsalemenCr["VirtualCode"] = $existing_master["VirtualCode"];
        $gltdsalemenCr["Status"] = "OPEN";
        $gltdsalemenCr["TDate"] = $currentdatetime;
        $gltdsalemenCr["BUnit"] = 1;
        $gltdsalemenCr["TBook"] = "POS";
        $gltdsalemenCr["TType"] = "Point OF Sale";
        $gltdsalemenCr["Narration"] = $commission_saleman_account_narration;
        $gltdsalemenCr["ParentAccountCode"] = $paccount_codesalemanCr;
        $gltdsalemenCr["AccountCode"] = 29;
        $gltdsalemenCr["Remarks"] = $row["Remarks"];
        $gltdsalemenCr["Amount"] = $master["Commission"];
        $gltdsalemenCr["StoreCode"] = 1;
        $gltdsalemenCr["Qty"] = $row["Qty"];
        $gltdsalemenCr["Rate"] = $row["Rate"];
        $gltdsalemenCr["UserName"] = $user["Code"];
        $gltdsalemenCr["CreateDate"] = $currentdatetime;
        $gltdsalemenCr["CreateTime"] = $currentdatetime;
        $gltdsalemenCr["Block"] = $row["Block"];
        $gltdsalemenCr["ProductCode"] = $row["ProductCode"];
        $gltdsalemenCr["ProductGroupCode"] = $row["ProductGroupCode"];
        $gltdsalemenCr["UnitCode"] = $row["UnitCode"];
        $gltdsalemenCr["TStatus"] = "Cr";
        DB::Insert("GLTD", $gltdsalemenCr);
    }
	

    // Step 7: Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Master and detail records updated successfully',
        'master_id' => $master_id
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error updating records: ' . $e->getMessage()]);
}